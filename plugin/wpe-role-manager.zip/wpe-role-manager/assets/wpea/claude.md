# CLAUDE.md — WP Easy Admin Framework

## files
- wpea-framework.css - main framework file
- wpea-wp-resets.css - resets to overcome default WP Admin styles
- test-ui.html - Sample HTML for usage of the framwork for admin UI
